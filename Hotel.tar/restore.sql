--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "DataBF";
--
-- Name: DataBF; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "DataBF" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "DataBF" OWNER TO postgres;

\connect "DataBF"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hotelchains; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA hotelchains;


ALTER SCHEMA hotelchains OWNER TO postgres;

--
-- Name: hotelchainschema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA hotelchainschema;


ALTER SCHEMA hotelchainschema OWNER TO postgres;

--
-- Name: hotelchainschema2; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA hotelchainschema2;


ALTER SCHEMA hotelchainschema2 OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: archive; Type: TABLE; Schema: hotelchains; Owner: postgres
--

CREATE TABLE hotelchains.archive (
    hotelid integer NOT NULL,
    roomid integer,
    roomstatus boolean,
    dates date
);


ALTER TABLE hotelchains.archive OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: hotelchains; Owner: postgres
--

CREATE TABLE hotelchains.customer (
    custid integer NOT NULL,
    name character varying(20),
    address character varying(20),
    regdate date,
    roomid integer
);


ALTER TABLE hotelchains.customer OWNER TO postgres;

--
-- Name: customer_custid_seq; Type: SEQUENCE; Schema: hotelchains; Owner: postgres
--

CREATE SEQUENCE hotelchains.customer_custid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchains.customer_custid_seq OWNER TO postgres;

--
-- Name: customer_custid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchains; Owner: postgres
--

ALTER SEQUENCE hotelchains.customer_custid_seq OWNED BY hotelchains.customer.custid;


--
-- Name: employee; Type: TABLE; Schema: hotelchains; Owner: postgres
--

CREATE TABLE hotelchains.employee (
    empid integer NOT NULL,
    name character varying(20),
    address character varying(20),
    emprole character varying(20),
    hotelid integer
);


ALTER TABLE hotelchains.employee OWNER TO postgres;

--
-- Name: employee_empid_seq; Type: SEQUENCE; Schema: hotelchains; Owner: postgres
--

CREATE SEQUENCE hotelchains.employee_empid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchains.employee_empid_seq OWNER TO postgres;

--
-- Name: employee_empid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchains; Owner: postgres
--

ALTER SEQUENCE hotelchains.employee_empid_seq OWNED BY hotelchains.employee.empid;


--
-- Name: hotelchain; Type: TABLE; Schema: hotelchains; Owner: postgres
--

CREATE TABLE hotelchains.hotelchain (
    name character varying(20) NOT NULL,
    totalhotels integer,
    address character varying(40),
    email text[],
    phoneno integer[]
);


ALTER TABLE hotelchains.hotelchain OWNER TO postgres;

--
-- Name: hotels; Type: TABLE; Schema: hotelchains; Owner: postgres
--

CREATE TABLE hotelchains.hotels (
    hotelid integer NOT NULL,
    category integer,
    address character varying(20),
    totalrooms integer,
    name character varying(20)
);


ALTER TABLE hotelchains.hotels OWNER TO postgres;

--
-- Name: hotels_hotelid_seq; Type: SEQUENCE; Schema: hotelchains; Owner: postgres
--

CREATE SEQUENCE hotelchains.hotels_hotelid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchains.hotels_hotelid_seq OWNER TO postgres;

--
-- Name: hotels_hotelid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchains; Owner: postgres
--

ALTER SEQUENCE hotelchains.hotels_hotelid_seq OWNED BY hotelchains.hotels.hotelid;


--
-- Name: manager; Type: TABLE; Schema: hotelchains; Owner: postgres
--

CREATE TABLE hotelchains.manager (
    empid integer NOT NULL,
    name character varying(20),
    address character varying(20),
    hotelid integer
);


ALTER TABLE hotelchains.manager OWNER TO postgres;

--
-- Name: manager_empid_seq; Type: SEQUENCE; Schema: hotelchains; Owner: postgres
--

CREATE SEQUENCE hotelchains.manager_empid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchains.manager_empid_seq OWNER TO postgres;

--
-- Name: manager_empid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchains; Owner: postgres
--

ALTER SEQUENCE hotelchains.manager_empid_seq OWNED BY hotelchains.manager.empid;


--
-- Name: rooms; Type: TABLE; Schema: hotelchains; Owner: postgres
--

CREATE TABLE hotelchains.rooms (
    roomid integer NOT NULL,
    capacity integer,
    status boolean,
    price numeric(2,0),
    roomview character varying(20),
    extension boolean,
    damages text,
    amenities character varying(20)[],
    hotelid integer
);


ALTER TABLE hotelchains.rooms OWNER TO postgres;

--
-- Name: rooms_roomid_seq; Type: SEQUENCE; Schema: hotelchains; Owner: postgres
--

CREATE SEQUENCE hotelchains.rooms_roomid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchains.rooms_roomid_seq OWNER TO postgres;

--
-- Name: rooms_roomid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchains; Owner: postgres
--

ALTER SEQUENCE hotelchains.rooms_roomid_seq OWNED BY hotelchains.rooms.roomid;


--
-- Name: archive; Type: TABLE; Schema: hotelchainschema; Owner: postgres
--

CREATE TABLE hotelchainschema.archive (
    hotelid integer NOT NULL,
    roomid integer NOT NULL,
    roomstatus boolean,
    dates date
);


ALTER TABLE hotelchainschema.archive OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: hotelchainschema; Owner: postgres
--

CREATE TABLE hotelchainschema.customer (
    custid integer NOT NULL,
    name character varying(20),
    address character varying(20),
    regdate date,
    roomid integer
);


ALTER TABLE hotelchainschema.customer OWNER TO postgres;

--
-- Name: customer_custid_seq; Type: SEQUENCE; Schema: hotelchainschema; Owner: postgres
--

CREATE SEQUENCE hotelchainschema.customer_custid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchainschema.customer_custid_seq OWNER TO postgres;

--
-- Name: customer_custid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchainschema; Owner: postgres
--

ALTER SEQUENCE hotelchainschema.customer_custid_seq OWNED BY hotelchainschema.customer.custid;


--
-- Name: employee; Type: TABLE; Schema: hotelchainschema; Owner: postgres
--

CREATE TABLE hotelchainschema.employee (
    empid integer NOT NULL,
    name character varying(20),
    address character varying(20),
    emprole character varying(20),
    hotelid integer
);


ALTER TABLE hotelchainschema.employee OWNER TO postgres;

--
-- Name: employee_empid_seq; Type: SEQUENCE; Schema: hotelchainschema; Owner: postgres
--

CREATE SEQUENCE hotelchainschema.employee_empid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchainschema.employee_empid_seq OWNER TO postgres;

--
-- Name: employee_empid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchainschema; Owner: postgres
--

ALTER SEQUENCE hotelchainschema.employee_empid_seq OWNED BY hotelchainschema.employee.empid;


--
-- Name: hotelchain; Type: TABLE; Schema: hotelchainschema; Owner: postgres
--

CREATE TABLE hotelchainschema.hotelchain (
    name character varying(20) NOT NULL,
    totalhotels integer,
    address character varying(40),
    emailaddress text[],
    phoneno integer[]
);


ALTER TABLE hotelchainschema.hotelchain OWNER TO postgres;

--
-- Name: hotels; Type: TABLE; Schema: hotelchainschema; Owner: postgres
--

CREATE TABLE hotelchainschema.hotels (
    hotelid integer NOT NULL,
    category integer,
    address character varying(20),
    totalrooms integer,
    name character varying(20)
);


ALTER TABLE hotelchainschema.hotels OWNER TO postgres;

--
-- Name: hotels_hotelid_seq; Type: SEQUENCE; Schema: hotelchainschema; Owner: postgres
--

CREATE SEQUENCE hotelchainschema.hotels_hotelid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchainschema.hotels_hotelid_seq OWNER TO postgres;

--
-- Name: hotels_hotelid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchainschema; Owner: postgres
--

ALTER SEQUENCE hotelchainschema.hotels_hotelid_seq OWNED BY hotelchainschema.hotels.hotelid;


--
-- Name: manager; Type: TABLE; Schema: hotelchainschema; Owner: postgres
--

CREATE TABLE hotelchainschema.manager (
    empid integer NOT NULL,
    name character varying(20),
    address character varying(20),
    hotelid integer
);


ALTER TABLE hotelchainschema.manager OWNER TO postgres;

--
-- Name: manager_empid_seq; Type: SEQUENCE; Schema: hotelchainschema; Owner: postgres
--

CREATE SEQUENCE hotelchainschema.manager_empid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchainschema.manager_empid_seq OWNER TO postgres;

--
-- Name: manager_empid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchainschema; Owner: postgres
--

ALTER SEQUENCE hotelchainschema.manager_empid_seq OWNED BY hotelchainschema.manager.empid;


--
-- Name: rooms; Type: TABLE; Schema: hotelchainschema; Owner: postgres
--

CREATE TABLE hotelchainschema.rooms (
    roomid integer NOT NULL,
    capacity integer,
    status character varying(255),
    price numeric(2,0),
    roomview character varying(20),
    extension boolean,
    damages text,
    amenities character varying(20)[],
    hotelid integer,
    date_from date,
    date_to date
);


ALTER TABLE hotelchainschema.rooms OWNER TO postgres;

--
-- Name: rooms_roomid_seq; Type: SEQUENCE; Schema: hotelchainschema; Owner: postgres
--

CREATE SEQUENCE hotelchainschema.rooms_roomid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchainschema.rooms_roomid_seq OWNER TO postgres;

--
-- Name: rooms_roomid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchainschema; Owner: postgres
--

ALTER SEQUENCE hotelchainschema.rooms_roomid_seq OWNED BY hotelchainschema.rooms.roomid;


--
-- Name: archive; Type: TABLE; Schema: hotelchainschema2; Owner: postgres
--

CREATE TABLE hotelchainschema2.archive (
    hotelid integer NOT NULL,
    roomid integer NOT NULL,
    roomstatus boolean,
    dates date
);


ALTER TABLE hotelchainschema2.archive OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: hotelchainschema2; Owner: postgres
--

CREATE TABLE hotelchainschema2.customer (
    custid integer NOT NULL,
    name character varying(20),
    address character varying(20),
    regdate date,
    roomid integer
);


ALTER TABLE hotelchainschema2.customer OWNER TO postgres;

--
-- Name: customer_custid_seq; Type: SEQUENCE; Schema: hotelchainschema2; Owner: postgres
--

CREATE SEQUENCE hotelchainschema2.customer_custid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchainschema2.customer_custid_seq OWNER TO postgres;

--
-- Name: customer_custid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchainschema2; Owner: postgres
--

ALTER SEQUENCE hotelchainschema2.customer_custid_seq OWNED BY hotelchainschema2.customer.custid;


--
-- Name: employee; Type: TABLE; Schema: hotelchainschema2; Owner: postgres
--

CREATE TABLE hotelchainschema2.employee (
    empid integer NOT NULL,
    name character varying(20),
    address character varying(20),
    emprole character varying(20),
    hotelid integer
);


ALTER TABLE hotelchainschema2.employee OWNER TO postgres;

--
-- Name: employee_empid_seq; Type: SEQUENCE; Schema: hotelchainschema2; Owner: postgres
--

CREATE SEQUENCE hotelchainschema2.employee_empid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchainschema2.employee_empid_seq OWNER TO postgres;

--
-- Name: employee_empid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchainschema2; Owner: postgres
--

ALTER SEQUENCE hotelchainschema2.employee_empid_seq OWNED BY hotelchainschema2.employee.empid;


--
-- Name: hotelchain; Type: TABLE; Schema: hotelchainschema2; Owner: postgres
--

CREATE TABLE hotelchainschema2.hotelchain (
    name character varying(20) NOT NULL,
    totalhotels integer,
    address character varying(40),
    emailaddress text[],
    phoneno integer[]
);


ALTER TABLE hotelchainschema2.hotelchain OWNER TO postgres;

--
-- Name: hotels; Type: TABLE; Schema: hotelchainschema2; Owner: postgres
--

CREATE TABLE hotelchainschema2.hotels (
    hotelid integer NOT NULL,
    category integer,
    address character varying(20),
    totalrooms integer,
    name character varying(20)
);


ALTER TABLE hotelchainschema2.hotels OWNER TO postgres;

--
-- Name: hotels_hotelid_seq; Type: SEQUENCE; Schema: hotelchainschema2; Owner: postgres
--

CREATE SEQUENCE hotelchainschema2.hotels_hotelid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchainschema2.hotels_hotelid_seq OWNER TO postgres;

--
-- Name: hotels_hotelid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchainschema2; Owner: postgres
--

ALTER SEQUENCE hotelchainschema2.hotels_hotelid_seq OWNED BY hotelchainschema2.hotels.hotelid;


--
-- Name: manager; Type: TABLE; Schema: hotelchainschema2; Owner: postgres
--

CREATE TABLE hotelchainschema2.manager (
    empid integer NOT NULL,
    name character varying(20),
    address character varying(20),
    hotelid integer
);


ALTER TABLE hotelchainschema2.manager OWNER TO postgres;

--
-- Name: manager_empid_seq; Type: SEQUENCE; Schema: hotelchainschema2; Owner: postgres
--

CREATE SEQUENCE hotelchainschema2.manager_empid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchainschema2.manager_empid_seq OWNER TO postgres;

--
-- Name: manager_empid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchainschema2; Owner: postgres
--

ALTER SEQUENCE hotelchainschema2.manager_empid_seq OWNED BY hotelchainschema2.manager.empid;


--
-- Name: rooms; Type: TABLE; Schema: hotelchainschema2; Owner: postgres
--

CREATE TABLE hotelchainschema2.rooms (
    roomid integer NOT NULL,
    capacity integer,
    status boolean,
    price numeric(2,0),
    roomview character varying(20),
    extension boolean,
    damages text,
    amenities character varying(20)[],
    hotelid integer,
    date_from date,
    date_to date
);


ALTER TABLE hotelchainschema2.rooms OWNER TO postgres;

--
-- Name: rooms_roomid_seq; Type: SEQUENCE; Schema: hotelchainschema2; Owner: postgres
--

CREATE SEQUENCE hotelchainschema2.rooms_roomid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hotelchainschema2.rooms_roomid_seq OWNER TO postgres;

--
-- Name: rooms_roomid_seq; Type: SEQUENCE OWNED BY; Schema: hotelchainschema2; Owner: postgres
--

ALTER SEQUENCE hotelchainschema2.rooms_roomid_seq OWNED BY hotelchainschema2.rooms.roomid;


--
-- Name: customer custid; Type: DEFAULT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.customer ALTER COLUMN custid SET DEFAULT nextval('hotelchains.customer_custid_seq'::regclass);


--
-- Name: employee empid; Type: DEFAULT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.employee ALTER COLUMN empid SET DEFAULT nextval('hotelchains.employee_empid_seq'::regclass);


--
-- Name: hotels hotelid; Type: DEFAULT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.hotels ALTER COLUMN hotelid SET DEFAULT nextval('hotelchains.hotels_hotelid_seq'::regclass);


--
-- Name: manager empid; Type: DEFAULT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.manager ALTER COLUMN empid SET DEFAULT nextval('hotelchains.manager_empid_seq'::regclass);


--
-- Name: rooms roomid; Type: DEFAULT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.rooms ALTER COLUMN roomid SET DEFAULT nextval('hotelchains.rooms_roomid_seq'::regclass);


--
-- Name: customer custid; Type: DEFAULT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.customer ALTER COLUMN custid SET DEFAULT nextval('hotelchainschema.customer_custid_seq'::regclass);


--
-- Name: employee empid; Type: DEFAULT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.employee ALTER COLUMN empid SET DEFAULT nextval('hotelchainschema.employee_empid_seq'::regclass);


--
-- Name: hotels hotelid; Type: DEFAULT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.hotels ALTER COLUMN hotelid SET DEFAULT nextval('hotelchainschema.hotels_hotelid_seq'::regclass);


--
-- Name: manager empid; Type: DEFAULT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.manager ALTER COLUMN empid SET DEFAULT nextval('hotelchainschema.manager_empid_seq'::regclass);


--
-- Name: rooms roomid; Type: DEFAULT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.rooms ALTER COLUMN roomid SET DEFAULT nextval('hotelchainschema.rooms_roomid_seq'::regclass);


--
-- Name: customer custid; Type: DEFAULT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.customer ALTER COLUMN custid SET DEFAULT nextval('hotelchainschema2.customer_custid_seq'::regclass);


--
-- Name: employee empid; Type: DEFAULT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.employee ALTER COLUMN empid SET DEFAULT nextval('hotelchainschema2.employee_empid_seq'::regclass);


--
-- Name: hotels hotelid; Type: DEFAULT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.hotels ALTER COLUMN hotelid SET DEFAULT nextval('hotelchainschema2.hotels_hotelid_seq'::regclass);


--
-- Name: manager empid; Type: DEFAULT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.manager ALTER COLUMN empid SET DEFAULT nextval('hotelchainschema2.manager_empid_seq'::regclass);


--
-- Name: rooms roomid; Type: DEFAULT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.rooms ALTER COLUMN roomid SET DEFAULT nextval('hotelchainschema2.rooms_roomid_seq'::regclass);


--
-- Data for Name: archive; Type: TABLE DATA; Schema: hotelchains; Owner: postgres
--

COPY hotelchains.archive (hotelid, roomid, roomstatus, dates) FROM stdin;
\.
COPY hotelchains.archive (hotelid, roomid, roomstatus, dates) FROM '$$PATH$$/3499.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: hotelchains; Owner: postgres
--

COPY hotelchains.customer (custid, name, address, regdate, roomid) FROM stdin;
\.
COPY hotelchains.customer (custid, name, address, regdate, roomid) FROM '$$PATH$$/3492.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: hotelchains; Owner: postgres
--

COPY hotelchains.employee (empid, name, address, emprole, hotelid) FROM stdin;
\.
COPY hotelchains.employee (empid, name, address, emprole, hotelid) FROM '$$PATH$$/3494.dat';

--
-- Data for Name: hotelchain; Type: TABLE DATA; Schema: hotelchains; Owner: postgres
--

COPY hotelchains.hotelchain (name, totalhotels, address, email, phoneno) FROM stdin;
\.
COPY hotelchains.hotelchain (name, totalhotels, address, email, phoneno) FROM '$$PATH$$/3488.dat';

--
-- Data for Name: hotels; Type: TABLE DATA; Schema: hotelchains; Owner: postgres
--

COPY hotelchains.hotels (hotelid, category, address, totalrooms, name) FROM stdin;
\.
COPY hotelchains.hotels (hotelid, category, address, totalrooms, name) FROM '$$PATH$$/3498.dat';

--
-- Data for Name: manager; Type: TABLE DATA; Schema: hotelchains; Owner: postgres
--

COPY hotelchains.manager (empid, name, address, hotelid) FROM stdin;
\.
COPY hotelchains.manager (empid, name, address, hotelid) FROM '$$PATH$$/3496.dat';

--
-- Data for Name: rooms; Type: TABLE DATA; Schema: hotelchains; Owner: postgres
--

COPY hotelchains.rooms (roomid, capacity, status, price, roomview, extension, damages, amenities, hotelid) FROM stdin;
\.
COPY hotelchains.rooms (roomid, capacity, status, price, roomview, extension, damages, amenities, hotelid) FROM '$$PATH$$/3490.dat';

--
-- Data for Name: archive; Type: TABLE DATA; Schema: hotelchainschema; Owner: postgres
--

COPY hotelchainschema.archive (hotelid, roomid, roomstatus, dates) FROM stdin;
\.
COPY hotelchainschema.archive (hotelid, roomid, roomstatus, dates) FROM '$$PATH$$/3512.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: hotelchainschema; Owner: postgres
--

COPY hotelchainschema.customer (custid, name, address, regdate, roomid) FROM stdin;
\.
COPY hotelchainschema.customer (custid, name, address, regdate, roomid) FROM '$$PATH$$/3513.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: hotelchainschema; Owner: postgres
--

COPY hotelchainschema.employee (empid, name, address, emprole, hotelid) FROM stdin;
\.
COPY hotelchainschema.employee (empid, name, address, emprole, hotelid) FROM '$$PATH$$/3515.dat';

--
-- Data for Name: hotelchain; Type: TABLE DATA; Schema: hotelchainschema; Owner: postgres
--

COPY hotelchainschema.hotelchain (name, totalhotels, address, emailaddress, phoneno) FROM stdin;
\.
COPY hotelchainschema.hotelchain (name, totalhotels, address, emailaddress, phoneno) FROM '$$PATH$$/3517.dat';

--
-- Data for Name: hotels; Type: TABLE DATA; Schema: hotelchainschema; Owner: postgres
--

COPY hotelchainschema.hotels (hotelid, category, address, totalrooms, name) FROM stdin;
\.
COPY hotelchainschema.hotels (hotelid, category, address, totalrooms, name) FROM '$$PATH$$/3518.dat';

--
-- Data for Name: manager; Type: TABLE DATA; Schema: hotelchainschema; Owner: postgres
--

COPY hotelchainschema.manager (empid, name, address, hotelid) FROM stdin;
\.
COPY hotelchainschema.manager (empid, name, address, hotelid) FROM '$$PATH$$/3520.dat';

--
-- Data for Name: rooms; Type: TABLE DATA; Schema: hotelchainschema; Owner: postgres
--

COPY hotelchainschema.rooms (roomid, capacity, status, price, roomview, extension, damages, amenities, hotelid, date_from, date_to) FROM stdin;
\.
COPY hotelchainschema.rooms (roomid, capacity, status, price, roomview, extension, damages, amenities, hotelid, date_from, date_to) FROM '$$PATH$$/3522.dat';

--
-- Data for Name: archive; Type: TABLE DATA; Schema: hotelchainschema2; Owner: postgres
--

COPY hotelchainschema2.archive (hotelid, roomid, roomstatus, dates) FROM stdin;
\.
COPY hotelchainschema2.archive (hotelid, roomid, roomstatus, dates) FROM '$$PATH$$/3500.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: hotelchainschema2; Owner: postgres
--

COPY hotelchainschema2.customer (custid, name, address, regdate, roomid) FROM stdin;
\.
COPY hotelchainschema2.customer (custid, name, address, regdate, roomid) FROM '$$PATH$$/3501.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: hotelchainschema2; Owner: postgres
--

COPY hotelchainschema2.employee (empid, name, address, emprole, hotelid) FROM stdin;
\.
COPY hotelchainschema2.employee (empid, name, address, emprole, hotelid) FROM '$$PATH$$/3503.dat';

--
-- Data for Name: hotelchain; Type: TABLE DATA; Schema: hotelchainschema2; Owner: postgres
--

COPY hotelchainschema2.hotelchain (name, totalhotels, address, emailaddress, phoneno) FROM stdin;
\.
COPY hotelchainschema2.hotelchain (name, totalhotels, address, emailaddress, phoneno) FROM '$$PATH$$/3505.dat';

--
-- Data for Name: hotels; Type: TABLE DATA; Schema: hotelchainschema2; Owner: postgres
--

COPY hotelchainschema2.hotels (hotelid, category, address, totalrooms, name) FROM stdin;
\.
COPY hotelchainschema2.hotels (hotelid, category, address, totalrooms, name) FROM '$$PATH$$/3506.dat';

--
-- Data for Name: manager; Type: TABLE DATA; Schema: hotelchainschema2; Owner: postgres
--

COPY hotelchainschema2.manager (empid, name, address, hotelid) FROM stdin;
\.
COPY hotelchainschema2.manager (empid, name, address, hotelid) FROM '$$PATH$$/3508.dat';

--
-- Data for Name: rooms; Type: TABLE DATA; Schema: hotelchainschema2; Owner: postgres
--

COPY hotelchainschema2.rooms (roomid, capacity, status, price, roomview, extension, damages, amenities, hotelid, date_from, date_to) FROM stdin;
\.
COPY hotelchainschema2.rooms (roomid, capacity, status, price, roomview, extension, damages, amenities, hotelid, date_from, date_to) FROM '$$PATH$$/3510.dat';

--
-- Name: customer_custid_seq; Type: SEQUENCE SET; Schema: hotelchains; Owner: postgres
--

SELECT pg_catalog.setval('hotelchains.customer_custid_seq', 106, true);


--
-- Name: employee_empid_seq; Type: SEQUENCE SET; Schema: hotelchains; Owner: postgres
--

SELECT pg_catalog.setval('hotelchains.employee_empid_seq', 1, false);


--
-- Name: hotels_hotelid_seq; Type: SEQUENCE SET; Schema: hotelchains; Owner: postgres
--

SELECT pg_catalog.setval('hotelchains.hotels_hotelid_seq', 52, true);


--
-- Name: manager_empid_seq; Type: SEQUENCE SET; Schema: hotelchains; Owner: postgres
--

SELECT pg_catalog.setval('hotelchains.manager_empid_seq', 1, false);


--
-- Name: rooms_roomid_seq; Type: SEQUENCE SET; Schema: hotelchains; Owner: postgres
--

SELECT pg_catalog.setval('hotelchains.rooms_roomid_seq', 1, false);


--
-- Name: customer_custid_seq; Type: SEQUENCE SET; Schema: hotelchainschema; Owner: postgres
--

SELECT pg_catalog.setval('hotelchainschema.customer_custid_seq', 106, true);


--
-- Name: employee_empid_seq; Type: SEQUENCE SET; Schema: hotelchainschema; Owner: postgres
--

SELECT pg_catalog.setval('hotelchainschema.employee_empid_seq', 1, false);


--
-- Name: hotels_hotelid_seq; Type: SEQUENCE SET; Schema: hotelchainschema; Owner: postgres
--

SELECT pg_catalog.setval('hotelchainschema.hotels_hotelid_seq', 52, true);


--
-- Name: manager_empid_seq; Type: SEQUENCE SET; Schema: hotelchainschema; Owner: postgres
--

SELECT pg_catalog.setval('hotelchainschema.manager_empid_seq', 1, false);


--
-- Name: rooms_roomid_seq; Type: SEQUENCE SET; Schema: hotelchainschema; Owner: postgres
--

SELECT pg_catalog.setval('hotelchainschema.rooms_roomid_seq', 1, false);


--
-- Name: customer_custid_seq; Type: SEQUENCE SET; Schema: hotelchainschema2; Owner: postgres
--

SELECT pg_catalog.setval('hotelchainschema2.customer_custid_seq', 106, true);


--
-- Name: employee_empid_seq; Type: SEQUENCE SET; Schema: hotelchainschema2; Owner: postgres
--

SELECT pg_catalog.setval('hotelchainschema2.employee_empid_seq', 1, false);


--
-- Name: hotels_hotelid_seq; Type: SEQUENCE SET; Schema: hotelchainschema2; Owner: postgres
--

SELECT pg_catalog.setval('hotelchainschema2.hotels_hotelid_seq', 60, true);


--
-- Name: manager_empid_seq; Type: SEQUENCE SET; Schema: hotelchainschema2; Owner: postgres
--

SELECT pg_catalog.setval('hotelchainschema2.manager_empid_seq', 1, false);


--
-- Name: rooms_roomid_seq; Type: SEQUENCE SET; Schema: hotelchainschema2; Owner: postgres
--

SELECT pg_catalog.setval('hotelchainschema2.rooms_roomid_seq', 1, false);


--
-- Name: archive archive_pkey; Type: CONSTRAINT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.archive
    ADD CONSTRAINT archive_pkey PRIMARY KEY (hotelid);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (custid);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (empid);


--
-- Name: hotelchain hotelchain_pkey; Type: CONSTRAINT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.hotelchain
    ADD CONSTRAINT hotelchain_pkey PRIMARY KEY (name);


--
-- Name: hotels hotels_pkey; Type: CONSTRAINT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.hotels
    ADD CONSTRAINT hotels_pkey PRIMARY KEY (hotelid);


--
-- Name: manager manager_pkey; Type: CONSTRAINT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.manager
    ADD CONSTRAINT manager_pkey PRIMARY KEY (empid);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (roomid);


--
-- Name: archive archive_pkey; Type: CONSTRAINT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.archive
    ADD CONSTRAINT archive_pkey PRIMARY KEY (hotelid, roomid);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (custid);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (empid);


--
-- Name: hotelchain hotelchain_pkey; Type: CONSTRAINT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.hotelchain
    ADD CONSTRAINT hotelchain_pkey PRIMARY KEY (name);


--
-- Name: hotels hotels_pkey; Type: CONSTRAINT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.hotels
    ADD CONSTRAINT hotels_pkey PRIMARY KEY (hotelid);


--
-- Name: manager manager_pkey; Type: CONSTRAINT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.manager
    ADD CONSTRAINT manager_pkey PRIMARY KEY (empid);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (roomid);


--
-- Name: archive archive_pkey; Type: CONSTRAINT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.archive
    ADD CONSTRAINT archive_pkey PRIMARY KEY (hotelid, roomid);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (custid);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (empid);


--
-- Name: hotelchain hotelchain_pkey; Type: CONSTRAINT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.hotelchain
    ADD CONSTRAINT hotelchain_pkey PRIMARY KEY (name);


--
-- Name: hotels hotels_pkey; Type: CONSTRAINT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.hotels
    ADD CONSTRAINT hotels_pkey PRIMARY KEY (hotelid);


--
-- Name: manager manager_pkey; Type: CONSTRAINT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.manager
    ADD CONSTRAINT manager_pkey PRIMARY KEY (empid);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (roomid);


--
-- Name: customer_name_index; Type: INDEX; Schema: hotelchainschema; Owner: postgres
--

CREATE INDEX customer_name_index ON hotelchainschema.customer USING btree (name);


--
-- Name: employee_name_index; Type: INDEX; Schema: hotelchainschema; Owner: postgres
--

CREATE INDEX employee_name_index ON hotelchainschema.employee USING btree (name);


--
-- Name: hotel_address_index; Type: INDEX; Schema: hotelchainschema; Owner: postgres
--

CREATE INDEX hotel_address_index ON hotelchainschema.hotels USING btree (address);


--
-- Name: room_status_index; Type: INDEX; Schema: hotelchainschema; Owner: postgres
--

CREATE INDEX room_status_index ON hotelchainschema.rooms USING btree (status);


--
-- Name: customer customer_roomid_fkey; Type: FK CONSTRAINT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.customer
    ADD CONSTRAINT customer_roomid_fkey FOREIGN KEY (roomid) REFERENCES hotelchains.rooms(roomid);


--
-- Name: employee employee_hotelid_fkey; Type: FK CONSTRAINT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.employee
    ADD CONSTRAINT employee_hotelid_fkey FOREIGN KEY (hotelid) REFERENCES hotelchains.hotels(hotelid);


--
-- Name: hotels hotels_name_fkey; Type: FK CONSTRAINT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.hotels
    ADD CONSTRAINT hotels_name_fkey FOREIGN KEY (name) REFERENCES hotelchains.hotelchain(name);


--
-- Name: manager manager_hotelid_fkey; Type: FK CONSTRAINT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.manager
    ADD CONSTRAINT manager_hotelid_fkey FOREIGN KEY (hotelid) REFERENCES hotelchains.hotels(hotelid);


--
-- Name: rooms rooms_hotelid_fkey; Type: FK CONSTRAINT; Schema: hotelchains; Owner: postgres
--

ALTER TABLE ONLY hotelchains.rooms
    ADD CONSTRAINT rooms_hotelid_fkey FOREIGN KEY (hotelid) REFERENCES hotelchains.hotels(hotelid);


--
-- Name: customer customer_roomid_fkey; Type: FK CONSTRAINT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.customer
    ADD CONSTRAINT customer_roomid_fkey FOREIGN KEY (roomid) REFERENCES hotelchainschema.rooms(roomid);


--
-- Name: employee employee_hotelid_fkey; Type: FK CONSTRAINT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.employee
    ADD CONSTRAINT employee_hotelid_fkey FOREIGN KEY (hotelid) REFERENCES hotelchainschema.hotels(hotelid);


--
-- Name: hotels hotels_name_fkey; Type: FK CONSTRAINT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.hotels
    ADD CONSTRAINT hotels_name_fkey FOREIGN KEY (name) REFERENCES hotelchainschema.hotelchain(name);


--
-- Name: manager manager_hotelid_fkey; Type: FK CONSTRAINT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.manager
    ADD CONSTRAINT manager_hotelid_fkey FOREIGN KEY (hotelid) REFERENCES hotelchainschema.hotels(hotelid);


--
-- Name: rooms rooms_hotelid_fkey; Type: FK CONSTRAINT; Schema: hotelchainschema; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema.rooms
    ADD CONSTRAINT rooms_hotelid_fkey FOREIGN KEY (hotelid) REFERENCES hotelchainschema.hotels(hotelid);


--
-- Name: customer customer_roomid_fkey; Type: FK CONSTRAINT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.customer
    ADD CONSTRAINT customer_roomid_fkey FOREIGN KEY (roomid) REFERENCES hotelchainschema2.rooms(roomid);


--
-- Name: employee employee_hotelid_fkey; Type: FK CONSTRAINT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.employee
    ADD CONSTRAINT employee_hotelid_fkey FOREIGN KEY (hotelid) REFERENCES hotelchainschema2.hotels(hotelid);


--
-- Name: hotels hotels_name_fkey; Type: FK CONSTRAINT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.hotels
    ADD CONSTRAINT hotels_name_fkey FOREIGN KEY (name) REFERENCES hotelchainschema2.hotelchain(name);


--
-- Name: manager manager_hotelid_fkey; Type: FK CONSTRAINT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.manager
    ADD CONSTRAINT manager_hotelid_fkey FOREIGN KEY (hotelid) REFERENCES hotelchainschema2.hotels(hotelid);


--
-- Name: rooms rooms_hotelid_fkey; Type: FK CONSTRAINT; Schema: hotelchainschema2; Owner: postgres
--

ALTER TABLE ONLY hotelchainschema2.rooms
    ADD CONSTRAINT rooms_hotelid_fkey FOREIGN KEY (hotelid) REFERENCES hotelchainschema2.hotels(hotelid);


--
-- PostgreSQL database dump complete
--

